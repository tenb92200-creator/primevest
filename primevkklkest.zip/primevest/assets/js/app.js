// PrimeVest Frontend JS

document.addEventListener('DOMContentLoaded', function () {
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });

    // Confirm before withdraw / invest
    const confirmForms = document.querySelectorAll('form[data-confirm]');
    confirmForms.forEach(form => {
        form.addEventListener('submit', function (e) {
            const message = form.getAttribute('data-confirm') || 'Are you sure?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // Simple amount formatter
    const amountInputs = document.querySelectorAll('input[data-money]');
    amountInputs.forEach(input => {
        input.addEventListener('blur', function () {
            let val = parseFloat(this.value.replace(/[^0-9.]/g, ''));
            if (!isNaN(val)) {
                this.value = val.toFixed(2);
            }
        });
    });

    // Plan selection highlight
    const planCards = document.querySelectorAll('.card-plan');
    planCards.forEach(card => {
        card.addEventListener('click', function () {
            planCards.forEach(c => c.classList.remove('border-primary', 'border-3'));
            this.classList.add('border-primary', 'border-3');
        });
    });
});

// Utility
function showToast(message, type = 'success') {
    // Simple fallback if no toast system
    alert(message);
}
