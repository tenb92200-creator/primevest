</main>
<footer class="bg-dark text-white py-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5 class="fw-bold"><i class="bi bi-graph-up-arrow me-2"></i>PrimeVest</h5>
                <p class="text-muted">Smart investment platform for everyone. Grow your wealth with confidence.</p>
            </div>
            <div class="col-md-4 mb-4">
                <h6>Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="plans.php" class="text-muted text-decoration-none">Investment Plans</a></li>
                    <li><a href="login.php" class="text-muted text-decoration-none">Login</a></li>
                    <li><a href="register.php" class="text-muted text-decoration-none">Register</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-4">
                <h6>Support</h6>
                <p class="text-muted mb-1">Email: support@primevest.com</p>
                <p class="text-muted">This is a demo/prototype platform. No real money is involved.</p>
            </div>
        </div>
        <hr class="border-secondary">
        <div class="text-center text-muted">
            &copy; <?php echo date('Y'); ?> PrimeVest. All rights reserved. Demo purposes only.
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
